#include <bits/stdc++.h>
using namespace std;

bool one(string input); // a*
bool two(string input); // a*b+
bool three(string input); // abb