# Hello Moto
"""Ram aam khata hai"""