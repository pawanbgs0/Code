#include <bits/stdc++.h>
using namespace std;

int fibo(int n, vector<int> &dp);
int fibo_table(int n);
int fibo_optimised(int n);