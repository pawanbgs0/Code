#include <bits/stdc++.h>
using namespace std;

int mcm_recursive(int i, int j, vector<int> &arr, vector<vector<int>> &dp);
int mcm_tabulation(vector<int> &arr);