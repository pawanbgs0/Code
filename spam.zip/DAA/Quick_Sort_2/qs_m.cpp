#include "qs.h"

int main()
{
    // vector<int> arr = {10, 80, 30, 90, 40, 50, 70};

    // quick_sort(0, arr.size() - 1, arr);

    // for (int i = 0; i < arr.size(); i++)
    // {
    //     cout << arr[i] << " ";
    // }
    // cout << endl;

    for (int i = 0; i < 1; )
    time_measure_to_sort(1, 10000);

    return 0;
}