#include <bits/stdc++.h>
#include <cstdlib>

using namespace std;

class Huffman;
struct compare;

class Node
{
    Node* left;
    Node* right;
    char character;
    int freq;

    public:
        Node();
        Node(char character, int freq);
        friend Huffman;
        friend compare;
        friend istream &operator>>(istream &in, Huffman &ob);
        friend ostream &operator<<(ostream &out, Huffman &ob);
};


struct compare 
{
    bool operator()(Node* one, Node* two)
    {
        return (one->freq > two->freq);
    }
};


class Huffman
{
    bool is_decoded;
    Node* TreeRoot;
    string input; // collection of chars as a string taken input from the file.
    string encoded_output; // collection of 0 and 1 after the input encode
    string double_encoded;
    string decoded_output;
    string double_decoded;
    priority_queue<Node*, vector<Node*>, compare> queue; // min_heap to draw tree 
    unordered_map<char, string> codemap; // to store the code of different characters
    
    void freq_manager(); // counts the frequency and stores it in the min heap (queue)
    void calculate_tree();
    void code_generator_helper(Node* TreeRoot, string code);


    int binToDec(string inStr);
    string decToBin(int inNum);

    public:
        Huffman();
        Huffman(string file_name_with_extension);

        void encode();
        void decode();
        void saveEncodeFile(string file_name);
        void saveDecodeFile(string file_name);
       
        // Display Part
            void print_queue();
            void display_code();
            void freq();

        void take_input(string input_file_name);
        friend ostream &operator<<(ostream &out, Huffman &ob);
};