#include "huff.h"

Node::Node()
{
    this->left = NULL;
    this->right = NULL;
}

Node::Node(char character, int frequency)
{
    this->left = NULL;
    this->right = NULL;
    this->character = character;
    this->freq = frequency;
}


Huffman::Huffman()
{
    this->TreeRoot = NULL;
    this->is_decoded = false;
}

Huffman::Huffman(string input_file_name)
{
    this->TreeRoot = NULL;
    this->input = input_file_name;
    this->is_decoded = false;
}

void Huffman::freq_manager()
{
    unordered_map<char, int> frequency;

    for (int i = 0; i < this->input.size() - 1; i++) // -1 is to remove the duplicacy of last character as the last character is read twice while reading from file.
    {
        frequency[this->input[i]]++;
    }

    for (auto it = frequency.begin(); it != frequency.end(); it++)
    {   
        char charac = it->first;
        int freq = it->second;

        this->queue.push(new Node(charac, freq));
    }
}

void Huffman::calculate_tree()
{
    Node* one, *two, *sum;

    while (this->queue.size() != 1)
    {
        one = this->queue.top();
        this->queue.pop();
        
        two = this->queue.top();
        this->queue.pop();

        sum = new Node('$', one->freq + two->freq);
        sum->left = one;
        sum->right = two;

        this->queue.push(sum);
    }

    this->TreeRoot = queue.top();
}


void Huffman::code_generator_helper(Node* TreeRoot, string code)
{
    if (TreeRoot == NULL)
        return;

    if (TreeRoot->left == NULL && TreeRoot->right == NULL)
    {
        // cout << TreeRoot->character << " \t\t " << code << endl;
        this->codemap[TreeRoot->character] = code;
    }
    
    code_generator_helper(TreeRoot->left, code + "0");
    code_generator_helper(TreeRoot->right, code + "1");
}


void Huffman::encode()
{
    this->freq_manager();
    this->calculate_tree();
    this->code_generator_helper(this->TreeRoot, "");

    fstream f;

    f.open("result.bit", ios::out);

    for (int i = 0; i < this->input.size(); i++)
    {
        this->encoded_output += this->codemap[this->input[i]];

        f << this->codemap[this->input[i]];
    }
}


void Huffman::decode()
{
    Node* current = TreeRoot;

    if (TreeRoot == NULL)
        return;

    for (int i = 0; i < this->encoded_output.size(); i++)
    {
        char character = encoded_output[i];

        if (current->left == NULL && current->right == NULL)
        {
            decoded_output += current->character;
            current = TreeRoot;
        }

        if (encoded_output[i] == '0')
            current = current->left;

        else if (encoded_output[i] == '1')
            current = current->right;
        
        else
        {
            cout << "Message is not properly encoded." << endl;
            return;
        }
    }

    this->is_decoded = true;
}


void Huffman::print_queue()
{
    priority_queue<Node*, vector<Node*>, compare> current = this->queue;

    cout << endl << "Characters: \t Frequency: " << endl;

    while (!current.empty())
    {
        Node* temp = current.top();
        current.pop();

        cout << temp->character << " \t\t " << temp->freq << endl;
    }

}


void Huffman::display_code()
{
    string code;


    cout << endl << "Characters: \t Code: " << endl;

    for (auto it = this->codemap.begin(); it != codemap.end(); it++)
    {
        cout << it->first << "\t" << it->second << endl;
    }
} 


void Huffman::take_input(string input_file_name)
{
    fstream f;
    char temp;

    ifstream src(input_file_name); // checking if string is valid;
    

    if (src)
    {
        f.open(input_file_name.c_str(), ios::in);
        while (src.good())
        {
            src.get(temp);
            this->input += temp;
        } // this is taking last char twice
    }
    else 
        cout << "File does not exist." << endl;
}


ostream &operator<<(ostream &out, Huffman &ob)
{
    cout << endl << "Your encoded message is: ";
    cout << ob.encoded_output << endl << endl;

    if (ob.is_decoded)
    {
        cout << endl << "Your decoded message is: " << endl;
        cout << ob.decoded_output << endl << endl;
    }
    return out;
}

int Huffman::binToDec(string inStr) 
{
    int res = 0;
    for (auto c : inStr) {
        res = res * 2 + c - '0';
    }
    return res;
}


string Huffman::decToBin(int inNum) {
    string temp = "", res = "";
    while (inNum > 0) {
        temp += (inNum % 2 + '0');
        inNum /= 2;
    }
    res.append(8 - temp.length(), '0');
    for (int i = temp.length() - 1; i >= 0; i--) {
        res += temp[i];
    }
    return res;
}

void Huffman::saveEncodeFile(string file_name)
{
    int index = 0;
    fstream out;
    
    size_t lastindex = file_name.find_last_of("."); 
    string rawname = file_name.substr(0, lastindex); 

    rawname += "-encrypted.huf";

    out.open(rawname, ios::out);

    for (index = 0; index < encoded_output.size(); index = index + 8)
    {
        if (index + 8 > encoded_output.size())
            break;

        double_encoded += (char)binToDec(encoded_output.substr(index, index + 8));
        out << (char)binToDec(encoded_output.substr(index, index + 8));
    }

    int count = encoded_output.size() - (index + 1);
    string st;

	if (count > 0) 
    {
        for (; index < encoded_output.size(); index++)
        {
            st += encoded_output[index];
        }

        for (int i = 0; i < (8 - count); i++)
        {
            st += '0';
        }
	}

    double_encoded += st;

    
    // out << double_encoded;
    cout << double_encoded << endl;
}


void Huffman::saveDecodeFile(string file_name)
{
    int index = 0;
    fstream out;
    
    // size_t lastindex = file_name.find_last_of("."); 
    // string rawname = file_name.substr(0, lastindex); 

    // rawname += "-encrypted.huf";

    // out.open(rawname, ios::out);

    for (int i = 0; i < double_encoded.size(); i++)
    {
        double_decoded += this->decToBin(double_encoded[i]);
    }

    cout << double_decoded << endl;
    
    Node* current = TreeRoot;

    if (TreeRoot == NULL)
    {
        cout << "NULL";
        return;
    }
    for (int i = 0; i < this->double_decoded.size(); i++)
    {
        char character = double_decoded[i];

        if (current->left == NULL && current->right == NULL)
        {
            decoded_output += current->character;
            current = TreeRoot;
        }

        if (double_decoded[i] == '0')
            current = current->left;

        else if (double_decoded[i] == '1')
            current = current->right;
        
        else
        {
            cout << "Message is not properly encoded." << endl;
            return;
        }
    }
    out.open("double_output.txt", ios::out);

    out << decoded_output;
    cout << decoded_output << endl;
}