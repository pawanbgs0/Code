#include <bits/stdc++.h>
#include <fstream>
using namespace std;


int main()
{
    vector<bool> a(100, 1);

    fstream out;

    out.open("res.bin", ios::out | ios::binary);

    for (int i = 0; i < a.size(); i++)
    {
        out << a[i];
    }
    return 0;
}