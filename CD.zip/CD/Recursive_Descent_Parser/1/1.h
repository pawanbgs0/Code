#include <bits/stdc++.h>
using namespace std;

// E -> iF
// F -> +F / t

void match(string input, int &index, char ch);

void E(string input, int &index, bool &invalid);

void F(string input, int &index, bool &invalid);
