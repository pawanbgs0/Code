#include <bits/stdc++.h>
using namespace std;

// Data
    string file_to_string(string file_name_with_extension);


// Python
    bool single_line_comment_python(string code);
    bool multi_line_comment_python(string code);

// C/C++
    bool single_line_comment_C(string code);
    bool multi_line_comment_C(string code);